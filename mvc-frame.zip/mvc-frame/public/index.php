<?php

require_once'../app/bootstrap.php';

$route = new route;
 ?>

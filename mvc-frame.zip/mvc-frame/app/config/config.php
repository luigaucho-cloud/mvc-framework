<?php

define('SITENAME', '__YOUR SITNAME__');
define('DB_NAME', '__YOUR DB NAME__');
define('USER', '__YOUR USER__');
define('PASS', '__YOUR PASSOWRD__');

// your sitename
define('HOST', '__YOUR SITNAME__');

//site root
define('APPROOT', dirname(__DIR__));

//url root
define('URLROOT','_YOUR_URL_');




?>

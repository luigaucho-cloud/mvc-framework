<?php
require APPROOT.'/views/inc/header.php';
echo $data['name'];
echo'<br>';
echo $data['page'];

require APPROOT.'/views/inc/footer.php';
 ?>
